"""Global configuration and constants."""

import torch

device = "cuda" if torch.cuda.is_available() else "cpu"

IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".webp"]
K_VALUES = [1, 5, 10, 50]
MAP_K_VALUES = [5, 10, 50]

# Result.txt: α=0.5 best for OpenCLIP/CLIP; extremes (0/1) and full grids waste compute.
DEFAULT_ALPHAS = [0.5]
DEFAULT_BETAS = [0.5]

CLIP_CAPTION_PREFIX = "a photo of "
SEARLE_CAPTION_PREFIX = "a photo of $"

# Prefer methods that beat the flat sep/beta/fusion plateaus in Result.txt.
# Optional ablations remain available via --models clip_sep clip_beta open_clip_sep ...
DEFAULT_MODELS = [
    "open_clip",
    "open_clip_adaptive",
    "siglip",
    "searle",
    "ensemble",
]

DEFAULT_OPEN_CLIP_MODEL = "ViT-H-14"
DEFAULT_OPEN_CLIP_PRETRAINED = "./models_download/CLIP-ViT-H-14-laion2B-s32B-b79K/open_clip_pytorch_model.bin"

OPEN_CLIP_MODELS = ("open_clip", "open_clip_sep", "open_clip_beta", "open_clip_adaptive")

# Ensemble weights (OpenCLIP, SigLIP, SEARLE). Tuned from Result.txt leadership.
DEFAULT_ENSEMBLE_WEIGHTS_CIRR = (0.50, 0.35, 0.15)
DEFAULT_ENSEMBLE_WEIGHTS_CIRCO = (0.30, 0.25, 0.45)
DEFAULT_ENSEMBLE_ALPHA = 0.5
