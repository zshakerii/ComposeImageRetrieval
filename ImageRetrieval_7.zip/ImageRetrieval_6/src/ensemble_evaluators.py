"""Score-level ensemble: OpenCLIP + SigLIP + SEARLE."""

import torch
import torch.nn.functional as F
import clip
from tqdm import tqdm

from .config import (
    CLIP_CAPTION_PREFIX,
    SEARLE_CAPTION_PREFIX,
    DEFAULT_ENSEMBLE_ALPHA,
    device,
)
from .datasets import get_positives
from .metrics import init_results, update_metrics
from .models.open_clip import get_open_clip_text_feature
from .models.siglip import get_siglip_text_feature
from .ranking import exclude_reference, minmax_normalize, blend_similarities


def _caption(text: str) -> str:
    return CLIP_CAPTION_PREFIX + text


def _aligned_gallery_sims(ordered_ids, feat_cache, query_feat):
    """Cosine sims of query against feat_cache rows aligned to ordered_ids."""
    rows = []
    qdim = int(query_feat.reshape(-1).shape[0])
    for gid in ordered_ids:
        feat = feat_cache.get(gid)
        if feat is None:
            rows.append(torch.zeros(1, qdim))
        else:
            rows.append(feat.reshape(1, -1).float())
    gallery = F.normalize(torch.cat(rows, dim=0), dim=-1)
    q = F.normalize(query_feat.reshape(1, -1).float(), dim=-1)
    return torch.matmul(gallery, q.T).squeeze(-1)


def evaluate_ensemble(
    data,
    ordered_ids,
    *,
    open_clip_model,
    open_clip_tokenizer,
    open_clip_image_cache,
    siglip_model,
    siglip_processor,
    siglip_image_cache,
    searle_phi,
    encode_with_pseudo_tokens,
    clip_model,
    clip_image_cache,
    clip_image_cache_raw,
    weights,
    alpha=DEFAULT_ENSEMBLE_ALPHA,
):
    """
    Per-query weighted fusion of min-max-normalized similarity vectors.

    weights: (w_openclip, w_siglip, w_searle), need not sum to 1 (renormalized).
    """
    w = torch.tensor(weights, dtype=torch.float32)
    if float(w.sum()) <= 0:
        raise ValueError("ensemble weights must sum to a positive value")
    w = w / w.sum()

    oc_text_cache = {}
    sig_text_cache = {}
    results = init_results()
    total, skipped = 0, 0

    for item in tqdm(data, desc="Ensemble OpenCLIP+SigLIP+SEARLE"):
        reference_id = item["reference_id"]
        positives = get_positives(item)
        caption_full = _caption(item["caption"])
        searle_caption = SEARLE_CAPTION_PREFIX + item["caption"]

        oc_ref = open_clip_image_cache.get(reference_id)
        sig_ref = siglip_image_cache.get(reference_id)
        clip_ref = clip_image_cache.get(reference_id)
        clip_raw = clip_image_cache_raw.get(reference_id)

        if oc_ref is None or sig_ref is None or clip_ref is None or clip_raw is None:
            skipped += 1
            continue

        if caption_full not in oc_text_cache:
            oc_text_cache[caption_full] = get_open_clip_text_feature(
                caption_full, open_clip_model, open_clip_tokenizer
            )
        if caption_full not in sig_text_cache:
            sig_text_cache[caption_full] = get_siglip_text_feature(
                caption_full, siglip_model, siglip_processor
            )

        oc_txt = oc_text_cache[caption_full]
        sig_txt = sig_text_cache[caption_full]
        if oc_txt is None or sig_txt is None:
            skipped += 1
            continue

        try:
            sims_oc_txt = _aligned_gallery_sims(ordered_ids, open_clip_image_cache, oc_txt)
            sims_oc_ref = _aligned_gallery_sims(ordered_ids, open_clip_image_cache, oc_ref)
            sims_oc = blend_similarities(sims_oc_txt, sims_oc_ref, alpha)

            sims_sig_txt = _aligned_gallery_sims(ordered_ids, siglip_image_cache, sig_txt)
            sims_sig_ref = _aligned_gallery_sims(ordered_ids, siglip_image_cache, sig_ref)
            sims_sig = blend_similarities(sims_sig_txt, sims_sig_ref, alpha)

            with torch.no_grad():
                pseudo_tokens = searle_phi(clip_raw.float().to(device))
                tokenized = clip.tokenize([searle_caption], truncate=True).to(device)
                searle_q = encode_with_pseudo_tokens(clip_model, tokenized, pseudo_tokens)
                searle_q = F.normalize(searle_q.float(), dim=-1).cpu()
            sims_searle = _aligned_gallery_sims(ordered_ids, clip_image_cache, searle_q)

            sims = (
                float(w[0]) * minmax_normalize(sims_oc)
                + float(w[1]) * minmax_normalize(sims_sig)
                + float(w[2]) * minmax_normalize(sims_searle)
            )
            ranked_idx = torch.argsort(sims, descending=True).cpu().tolist()
            ranked_ids = exclude_reference(
                [ordered_ids[i] for i in ranked_idx], reference_id
            )
            update_metrics(results, ranked_ids, positives)
            total += 1
        except Exception:
            skipped += 1

    return results, total, skipped
