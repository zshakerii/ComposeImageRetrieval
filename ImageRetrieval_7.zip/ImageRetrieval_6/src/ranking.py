import torch


def rank_by_similarity(query_feat, gallery_feats):
    sims = torch.matmul(gallery_feats, query_feat.squeeze(0).float().T).squeeze(-1)
    ranked_idx = torch.argsort(sims, descending=True)
    return ranked_idx.cpu().tolist()


def exclude_reference(ranked_ids, reference_id):
    """Remove the query reference image from the ranked gallery list."""
    if reference_id is None:
        return ranked_ids
    return [img_id for img_id in ranked_ids if img_id != reference_id]


def minmax_normalize(sims):
    """نرمال‌سازی per-query در بازه [0,1]"""
    s = sims.squeeze(-1)
    s_min = s.min()
    s_max = s.max()
    if (s_max - s_min) < 1e-8:
        return torch.zeros_like(s)
    return (s - s_min) / (s_max - s_min)


def adaptive_blend_alpha(sims_txt, sims_ref, alpha_min=0.25, alpha_max=0.75, default=0.5):
    """
    Query-adaptive α for composed retrieval.

    Result.txt: fixed α≈0.5 is best; α=1.0 collapses; α=0 is competitive on R@1.
    Raise α when the text similarity distribution is peaked (confident relative caption);
    otherwise lean toward the reference image. Clamped away from {0,1}.
    """
    del sims_ref  # reserved for future disagreement features
    st = minmax_normalize(sims_txt)
    if st.numel() < 2:
        return default
    top2 = torch.topk(st, k=2).values
    margin = float((top2[0] - top2[1]).item())
    # Map typical margins onto [alpha_min, alpha_max]
    t = min(max(margin / 0.12, 0.0), 1.0)
    return alpha_min + (alpha_max - alpha_min) * t


def blend_similarities(sims_txt, sims_ref, alpha):
    return alpha * sims_txt + (1.0 - alpha) * sims_ref
