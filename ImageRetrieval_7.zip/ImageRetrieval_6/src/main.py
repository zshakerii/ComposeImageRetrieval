import argparse
import traceback

import torch

from .config import (
    DEFAULT_ALPHAS,
    DEFAULT_BETAS,
    DEFAULT_MODELS,
    DEFAULT_OPEN_CLIP_MODEL,
    DEFAULT_OPEN_CLIP_PRETRAINED,
    DEFAULT_ENSEMBLE_WEIGHTS_CIRR,
    DEFAULT_ENSEMBLE_WEIGHTS_CIRCO,
    DEFAULT_ENSEMBLE_ALPHA,
    OPEN_CLIP_MODELS,
    device,
)
from .datasets import load_dataset
from .io_utils import list_image_ids_in_folder, load_generated_captions
from .metrics import summarize_results
from .cache import (
    build_clip_image_cache,
    build_generic_image_cache,
    build_open_clip_image_cache,
    build_siglip_batch_cache,
    build_qwen_batch_cache,
    stack_feature_cache,
)

from .models.clip import get_clip_image_feature,get_clip_text_feature,load_clip_model
from .models.qwen import get_qwen_text_feature,get_qwen_image_feature,load_qwen_model
from .models.searle import load_searle_model,load_searle_config,load_searle_preprocess
from .models.lava import get_lava_text_feature,get_lava_image_feature,load_lava_model
from .models.open_clip import load_open_clip_model,get_open_clip_image_feature,get_open_clip_text_feature
from .models.blip import get_blip_text_feature,get_blip_image_feature,load_blip_model
from .models.siglip import get_siglip_image_feature,get_siglip_text_feature,load_siglip_model


from .evaluators import (
    evaluate_clip_alphas,
    evaluate_clip_alphas_separate,
    evaluate_clip_adaptive,
    evaluate_clip_beta,
    evaluate_searle,
    evaluate_generic,
)
from .open_clip_evaluators import (
    evaluate_open_clip_alphas,
    evaluate_open_clip_alphas_separate,
    evaluate_open_clip_adaptive,
    evaluate_open_clip_beta,
)
from .ensemble_evaluators import evaluate_ensemble


def build_arg_parser():
    parser = argparse.ArgumentParser(description="Unified Evaluation for CIRR and CIRCO")
    parser.add_argument("--dataset", type=str, choices=["cirr", "circo"], required=True)
    parser.add_argument("--image_folder", type=str, required=True)
    parser.add_argument("--json_path", type=str, required=True)
    parser.add_argument("--alphas", type=float, nargs="+", default=DEFAULT_ALPHAS)
    parser.add_argument("--betas", type=float, nargs="+", default=DEFAULT_BETAS)
    parser.add_argument("--qwen_model_path", type=str, default=None)
    parser.add_argument("--blip_model_path", type=str, default=None)
    parser.add_argument("--siglip_path", type=str, default=None)
    parser.add_argument("--generated_captions_path", type=str, default=None)
    parser.add_argument("--open_clip_model_name", type=str, default=DEFAULT_OPEN_CLIP_MODEL)
    parser.add_argument("--open_clip_pretrained", type=str, default=DEFAULT_OPEN_CLIP_PRETRAINED)
    parser.add_argument("--models", type=str, nargs="+", default=DEFAULT_MODELS)
    parser.add_argument(
        "--ensemble_weights",
        type=float,
        nargs=3,
        default=None,
        help="Weights for ensemble: OpenCLIP SigLIP SEARLE (default depends on dataset)",
    )
    parser.add_argument(
        "--ensemble_alpha",
        type=float,
        default=DEFAULT_ENSEMBLE_ALPHA,
        help="Fixed α for OpenCLIP/SigLIP branches inside the ensemble",
    )
    return parser


def collect_image_ids(data, image_folder=None):
    """Union of annotation-linked IDs and all images in the gallery folder."""
    image_ids = set()
    for item in data:
        image_ids.add(item["reference_id"])
        image_ids.add(item["target_id"])
        for member in item.get("members", []):
            image_ids.add(member)
        for pos in item.get("positives", []):
            image_ids.add(pos)

    if image_folder:
        image_ids |= list_image_ids_in_folder(image_folder)
    return image_ids


def print_results_table(args, all_results):
    print("\n" + "=" * 140)
    print(f"📋 جدول مقایسه‌ای {args.dataset.upper()} (Open-set gallery, reference excluded)")
    print("=" * 140)

    header = (
        f"{'Model/Alpha':<24} {'MRR':<10} {'mAP@5':<10} {'mAP@10':<10} {'mAP@50':<10} "
        f"{'Prec@1':<10} {'Prec@5':<10} {'Prec@10':<10} {'Prec@50':<10} "
        f"{'Rec@1':<10} {'Rec@5':<10} {'Rec@10':<10} {'Rec@50':<10}"
    )
    print(header)
    print("-" * len(header))

    def row(name, r):
        print(
            f"{name:<24} {r['mrr']:<10.4f} {r['map5']:<10.4f} {r['map10']:<10.4f} {r['map50']:<10.4f} "
            f"{r['prec1']:<10.4f} {r['prec5']:<10.4f} {r['prec10']:<10.4f} {r['prec50']:<10.4f} "
            f"{r['rec1']:<10.4f} {r['rec5']:<10.4f} {r['rec10']:<10.4f} {r['rec50']:<10.4f}"
        )

    for alpha in sorted(args.alphas):
        key = f"OpenCLIP alpha={alpha:.2f}"
        if key in all_results:
            row(key, all_results[key])

    if "OpenCLIP-adaptive" in all_results:
        row("OpenCLIP-adaptive", all_results["OpenCLIP-adaptive"])

    for alpha in sorted(args.alphas):
        key = f"OpenCLIP-sep alpha={alpha:.2f}"
        if key in all_results:
            row(key, all_results[key])

    for alpha in sorted(args.alphas):
        key = f"CLIP alpha={alpha:.2f}"
        if key in all_results:
            row(key, all_results[key])

    if "CLIP-adaptive" in all_results:
        row("CLIP-adaptive", all_results["CLIP-adaptive"])

    for alpha in sorted(args.alphas):
        key = f"CLIP-sep alpha={alpha:.2f}"
        if key in all_results:
            row(key, all_results[key])

    for beta in sorted(args.betas):
        for alpha in sorted(args.alphas):
            key = f"CLIP-beta a={alpha:.2f} b={beta:.2f}"
            if key in all_results:
                row(key, all_results[key])

    for beta in sorted(args.betas):
        for alpha in sorted(args.alphas):
            key = f"OpenCLIP-beta a={alpha:.2f} b={beta:.2f}"
            if key in all_results:
                row(key, all_results[key])

    for model_name in ["Ensemble", "Searle", "Qwen", "Blip", "LLaVA", "SigLIP"]:
        if model_name in all_results:
            row(model_name, all_results[model_name])


def main():
    args = build_arg_parser().parse_args()

    print(f"🔄 بارگذاری دیتاست {args.dataset.upper()}...")
    detected_dataset, data = load_dataset(args.json_path)
    if detected_dataset != args.dataset:
        raise ValueError(f"Dataset mismatch: arg={args.dataset}, detected={detected_dataset}")
    print(f"✅ تعداد {len(data)} نمونه بارگذاری شد.")

    image_ids = collect_image_ids(data, args.image_folder)
    print(f"✅ اندازه گالری Open-set: {len(image_ids)} تصویر")
    dataset_type = args.dataset

    all_results = {}
    clip_model = None
    preprocess = None
    gallery_ids = gallery_feats = None
    image_features_cache = image_features_cache_raw = None

    need_ensemble = "ensemble" in args.models
    need_clip_cache = any(
        m in args.models
        for m in ("clip", "clip_adaptive", "searle", "clip_sep", "clip_beta")
    ) or need_ensemble

    # نکته: توابع ارزیابی CLIP از clip.tokenize استفاده می‌کنند، پس مدل باید
    # از openai/CLIP بارگذاری شود (نه open_clip). بارگذاری تکراری اسکریپت اصلی حذف شد.
    if need_clip_cache:
        print("🔄 بارگذاری مدل CLIP و ساخت کش تصویر...")
        clip_model, preprocess = load_clip_model()
        image_features_cache, image_features_cache_raw = build_clip_image_cache(
            image_ids, args.image_folder, clip_model, preprocess, dataset_type
        )
        gallery_ids, gallery_feats = stack_feature_cache(image_features_cache)
    else:
        print("⏭️  مدل‌های مبتنی بر CLIP انتخاب نشده‌اند؛ کش CLIP ساخته نمی‌شود.")

    need_open_clip_cache = any(m in args.models for m in OPEN_CLIP_MODELS) or need_ensemble
    open_clip_model = open_clip_tokenizer = None
    oc_gallery_ids = oc_gallery_feats = None
    open_clip_image_cache = None

    if need_open_clip_cache:
        print("🔄 بارگذاری مدل OpenCLIP و ساخت کش تصویر...")
        open_clip_model, open_clip_preprocess, open_clip_tokenizer = load_open_clip_model(
            args.open_clip_model_name, args.open_clip_pretrained
        )
        open_clip_image_cache = build_open_clip_image_cache(
            image_ids, args.image_folder, open_clip_model, open_clip_preprocess, dataset_type
        )
        oc_gallery_ids, oc_gallery_feats = stack_feature_cache(open_clip_image_cache)
        print(f"✅ تعداد {len(open_clip_image_cache)} تصویر OpenCLIP پردازش شد.")
    else:
        print("⏭️  مدل‌های OpenCLIP انتخاب نشده‌اند؛ کش OpenCLIP ساخته نمی‌شود.")

    # SigLIP may be needed alone or for ensemble — keep handles for reuse.
    need_siglip = "siglip" in args.models or need_ensemble
    siglip_model = siglip_processor = None
    siglip_image_features = None

    if need_siglip:
        if not args.siglip_path:
            print("❌ برای siglip/ensemble باید --siglip_path مشخص شود.")
            if need_ensemble:
                need_ensemble = False
        else:
            print("\n🔄 بارگذاری SigLIP و ساخت کش تصویر...")
            try:
                siglip_model, siglip_processor = load_siglip_model(args.siglip_path)
                siglip_image_features = build_siglip_batch_cache(
                    image_ids, args.image_folder, siglip_model, siglip_processor,
                    dataset_type=dataset_type, batch_size=16,
                )
                print(f"✅ تعداد {len(siglip_image_features)} تصویر SigLIP پردازش شد.")
            except Exception as e:
                print(f"❌ خطا در بارگذاری SigLIP: {e}")
                traceback.print_exc()
                if need_ensemble:
                    need_ensemble = False

    if "open_clip" in args.models:
        print("\n🔄 ارزیابی OpenCLIP")
        oc_results = evaluate_open_clip_alphas(
            data, open_clip_model, open_clip_tokenizer, open_clip_image_cache,
            oc_gallery_ids, oc_gallery_feats, args.alphas,
        )
        for alpha, (results, _, _) in oc_results.items():
            all_results[f"OpenCLIP alpha={alpha:.2f}"] = summarize_results(results)

    if "open_clip_adaptive" in args.models:
        print("\n🔄 ارزیابی OpenCLIP (adaptive α)")
        results, total, skipped, mean_alpha = evaluate_open_clip_adaptive(
            data, open_clip_model, open_clip_tokenizer, open_clip_image_cache,
            oc_gallery_ids, oc_gallery_feats,
        )
        print(f"✅ OpenCLIP-adaptive: {total} eval, {skipped} skipped, mean α={mean_alpha:.3f}")
        all_results["OpenCLIP-adaptive"] = summarize_results(results)

    if "open_clip_sep" in args.models:
        print("\n🔄 ارزیابی OpenCLIP (Separate + Normalized)")
        oc_sep_results = evaluate_open_clip_alphas_separate(
            data, open_clip_model, open_clip_tokenizer, open_clip_image_cache,
            oc_gallery_ids, oc_gallery_feats, args.alphas,
        )
        for alpha, (results, _, _) in oc_sep_results.items():
            all_results[f"OpenCLIP-sep alpha={alpha:.2f}"] = summarize_results(results)

    if "open_clip_beta" in args.models:
        print("\n🔄 ارزیابی OpenCLIP-Beta")
        if not args.generated_captions_path:
            print("❌ برای open_clip_beta باید --generated_captions_path مشخص شود.")
        else:
            generated_captions = load_generated_captions(args.generated_captions_path)
            print(f"✅ تعداد {len(generated_captions)} caption تولیدشده بارگذاری شد.")
            oc_beta_results = evaluate_open_clip_beta(
                data, open_clip_model, open_clip_tokenizer, open_clip_image_cache,
                oc_gallery_ids, oc_gallery_feats,
                generated_captions, args.alphas, args.betas,
            )
            for (alpha, beta), (results, _, _) in oc_beta_results.items():
                all_results[f"OpenCLIP-beta a={alpha:.2f} b={beta:.2f}"] = summarize_results(results)

    if "clip" in args.models:
        print("\n🔄 ارزیابی CLIP")
        clip_results = evaluate_clip_alphas(
            data, clip_model, image_features_cache, gallery_ids, gallery_feats, args.alphas
        )
        for alpha, (results, _, _) in clip_results.items():
            all_results[f"CLIP alpha={alpha:.2f}"] = summarize_results(results)

    if "clip_adaptive" in args.models:
        print("\n🔄 ارزیابی CLIP (adaptive α)")
        results, total, skipped, mean_alpha = evaluate_clip_adaptive(
            data, clip_model, image_features_cache, gallery_ids, gallery_feats
        )
        print(f"✅ CLIP-adaptive: {total} eval, {skipped} skipped, mean α={mean_alpha:.3f}")
        all_results["CLIP-adaptive"] = summarize_results(results)

    if "clip_sep" in args.models:
        print("\n🔄 ارزیابی CLIP (Separate + Normalized)")
        clip_sep_results = evaluate_clip_alphas_separate(
            data, clip_model, image_features_cache, gallery_ids, gallery_feats, args.alphas
        )
        for alpha, (results, _, _) in clip_sep_results.items():
            all_results[f"CLIP-sep alpha={alpha:.2f}"] = summarize_results(results)

    if "clip_beta" in args.models:
        print("\n🔄 ارزیابی CLIP-Beta")
        if not args.generated_captions_path:
            print("❌ برای clip_beta باید --generated_captions_path مشخص شود.")
        else:
            generated_captions = load_generated_captions(args.generated_captions_path)
            print(f"✅ تعداد {len(generated_captions)} caption تولیدشده بارگذاری شد.")
            beta_results = evaluate_clip_beta(
                data, clip_model, image_features_cache, gallery_ids, gallery_feats,
                generated_captions, args.alphas, args.betas
            )
            for (alpha, beta), (results, _, _) in beta_results.items():
                all_results[f"CLIP-beta a={alpha:.2f} b={beta:.2f}"] = summarize_results(results)

    searle_phi = encode_with_pseudo_tokens = None
    searle_clip_model = clip_model
    searle_image_cache = image_features_cache
    searle_image_cache_raw = image_features_cache_raw
    searle_gallery_ids, searle_gallery_feats = gallery_ids, gallery_feats

    if "searle" in args.models or need_ensemble:
        print("\n🔄 آماده‌سازی Searle (backbone + targetpad)")
        try:
            searle_config = load_searle_config()
            backbone = searle_config.get("backbone", "ViT-B/32")
            searle_phi, encode_with_pseudo_tokens = load_searle_model(
                searle_config, device=device
            )
            # Align CLIP backbone with SEARLE φ; prefer targetpad preprocess.
            searle_clip_model, clip_pp = load_clip_model(backbone)
            searle_pp = load_searle_preprocess(searle_config, fallback_preprocess=clip_pp)
            searle_image_cache, searle_image_cache_raw = build_clip_image_cache(
                image_ids, args.image_folder, searle_clip_model, searle_pp, dataset_type
            )
            searle_gallery_ids, searle_gallery_feats = stack_feature_cache(searle_image_cache)
            # Keep default clip_model in sync when SEARLE owns the CLIP tower.
            clip_model = searle_clip_model
            image_features_cache = searle_image_cache
            image_features_cache_raw = searle_image_cache_raw
            gallery_ids, gallery_feats = searle_gallery_ids, searle_gallery_feats
        except Exception as e:
            print(f"❌ خطا در آماده‌سازی Searle: {e}")
            traceback.print_exc()
            searle_phi = None
            if need_ensemble:
                need_ensemble = False

    if "searle" in args.models and searle_phi is not None:
        print("\n🔄 ارزیابی Searle")
        try:
            results, total, skipped = evaluate_searle(
                data, searle_phi, encode_with_pseudo_tokens, searle_clip_model,
                searle_image_cache, searle_image_cache_raw,
                searle_gallery_ids, searle_gallery_feats,
            )
            print(f"✅ Searle: {total} ارزیابی، {skipped} رد شد.")
            all_results["Searle"] = summarize_results(results)
        except Exception as e:
            print(f"❌ خطا در ارزیابی Searle: {e}")
            traceback.print_exc()

    if "siglip" in args.models and siglip_image_features:
        print("\n🔄 ارزیابی SigLIP")
        try:
            s_ids, s_feats = stack_feature_cache(siglip_image_features)
            results, total, skipped = evaluate_generic(
                data, args.image_folder, siglip_image_features, s_ids, s_feats,
                lambda img: get_siglip_image_feature(img, siglip_model, siglip_processor),
                lambda txt: get_siglip_text_feature(txt, siglip_model, siglip_processor),
                model_name="SigLIP", alpha=0.5, dataset_type=dataset_type,
            )
            print(f"✅ SigLIP: {total} ارزیابی، {skipped} رد شد.")
            all_results["SigLIP"] = summarize_results(results)
        except Exception as e:
            print(f"❌ خطا در ارزیابی SigLIP: {e}")
            traceback.print_exc()

    if need_ensemble and searle_phi is not None and siglip_image_features and open_clip_image_cache:
        print("\n🔄 ارزیابی Ensemble (OpenCLIP + SigLIP + SEARLE)")
        try:
            weights = args.ensemble_weights
            if weights is None:
                weights = (
                    DEFAULT_ENSEMBLE_WEIGHTS_CIRCO
                    if args.dataset == "circo"
                    else DEFAULT_ENSEMBLE_WEIGHTS_CIRR
                )
            print(f"   weights OpenCLIP/SigLIP/SEARLE = {tuple(weights)}")
            results, total, skipped = evaluate_ensemble(
                data,
                oc_gallery_ids,
                open_clip_model=open_clip_model,
                open_clip_tokenizer=open_clip_tokenizer,
                open_clip_image_cache=open_clip_image_cache,
                siglip_model=siglip_model,
                siglip_processor=siglip_processor,
                siglip_image_cache=siglip_image_features,
                searle_phi=searle_phi,
                encode_with_pseudo_tokens=encode_with_pseudo_tokens,
                clip_model=searle_clip_model,
                clip_image_cache=searle_image_cache,
                clip_image_cache_raw=searle_image_cache_raw,
                weights=weights,
                alpha=args.ensemble_alpha,
            )
            print(f"✅ Ensemble: {total} ارزیابی، {skipped} رد شد.")
            all_results["Ensemble"] = summarize_results(results)
        except Exception as e:
            print(f"❌ خطا در ارزیابی Ensemble: {e}")
            traceback.print_exc()

    if "qwen" in args.models:
        print("\n🔄 ارزیابی Qwen")
        try:
            model, processor = load_qwen_model(args.qwen_model_path, device)
            qwen_image_features = build_qwen_batch_cache(
                image_ids, args.image_folder, model, processor,
                batch_size=8, dataset_type=dataset_type,
            )
            print(f"✅ تعداد {len(qwen_image_features)} تصویر Qwen پردازش شد.")
            if qwen_image_features:
                q_ids, q_feats = stack_feature_cache(qwen_image_features)
                results, total, skipped = evaluate_generic(
                    data, args.image_folder, qwen_image_features, q_ids, q_feats,
                    lambda img: get_qwen_image_feature(img, model, processor, device),
                    lambda txt: get_qwen_text_feature(txt, model, processor, device),
                    model_name="Qwen", alpha=0.5, dataset_type=dataset_type,
                )
                print(f"✅ Qwen: {total} ارزیابی، {skipped} رد شد.")
                all_results["Qwen"] = summarize_results(results)
            else:
                print("❌ هیچ ویژگی تصویری Qwen استخراج نشد!")
        except Exception as e:
            print(f"❌ خطا در ارزیابی Qwen: {e}")
            traceback.print_exc()

    if "blip" in args.models:
        print("\n🔄 ارزیابی Blip")
        try:
            model, processor = load_blip_model(args.blip_model_path)
            blip_image_features = build_generic_image_cache(
                image_ids, args.image_folder,
                lambda img: get_blip_image_feature(img, model, processor),
                dataset_type=dataset_type,
            )
            print(f"✅ تعداد {len(blip_image_features)} تصویر Blip پردازش شد.")
            if blip_image_features:
                b_ids, b_feats = stack_feature_cache(blip_image_features)
                results, total, skipped = evaluate_generic(
                    data, args.image_folder, blip_image_features, b_ids, b_feats,
                    lambda img: get_blip_image_feature(img, model, processor),
                    lambda txt: get_blip_text_feature(txt, model, processor),
                    model_name="Blip", alpha=0.5, dataset_type=dataset_type,
                )
                print(f"✅ Blip: {total} ارزیابی، {skipped} رد شد.")
                all_results["Blip"] = summarize_results(results)
            else:
                print("⚠️ هیچ ویژگی تصویری برای Blip استخراج نشد.")

            del model, processor
            if "blip_image_features" in locals():
                del blip_image_features
            if "b_ids" in locals():
                del b_ids, b_feats
            torch.cuda.empty_cache()
        except Exception as e:
            print(f"❌ خطا در ارزیابی Blip: {e}")
            traceback.print_exc()

    if "lava" in args.models:
        print("\n🔄 ارزیابی LLaVA")
        try:
            model, processor = load_lava_model()
            lava_image_features = build_generic_image_cache(
                image_ids, args.image_folder,
                lambda img: get_lava_image_feature(img, model, processor),
                dataset_type=dataset_type,
            )
            if lava_image_features:
                l_ids, l_feats = stack_feature_cache(lava_image_features)
                results, total, skipped = evaluate_generic(
                    data, args.image_folder, lava_image_features, l_ids, l_feats,
                    lambda img: get_lava_image_feature(img, model, processor),
                    lambda txt: get_lava_text_feature(txt, model, processor),
                    model_name="LLaVA", alpha=0.5, dataset_type=dataset_type,
                )
                all_results["LLaVA"] = summarize_results(results)
        except Exception as e:
            print(f"❌ خطا در ارزیابی LLaVA: {e}")
            traceback.print_exc()

    print_results_table(args, all_results)


if __name__ == "__main__":
    main()
