import sys
import os
from contextlib import contextmanager
from typing import Optional, Tuple, Callable, Any

import torch
import yaml


@contextmanager
def _searle_import_context(searle_dir: str):
    """
    موقتاً محیط import را برای بارگذاری SEARLE آماده می‌کند:
    - SEARLE_DIR را ابتدای sys.path می‌گذارد تا src ریپوی SEARLE اولویت بگیرد
    - ماژول‌های src کش‌شده‌ی پروژه‌ی کاربر را کنار می‌گذارد
    - در پایان، وضعیت اولیه‌ی sys.path و sys.modules را بازمی‌گرداند
    """
    original_sys_path = list(sys.path)

    stashed_modules = {}
    for name in list(sys.modules.keys()):
        if name == "src" or name.startswith("src."):
            stashed_modules[name] = sys.modules.pop(name)

    sys.path.insert(0, searle_dir)

    try:
        yield
    finally:
        sys.path[:] = original_sys_path

        for name in list(sys.modules.keys()):
            if name == "src" or name.startswith("src."):
                del sys.modules[name]

        sys.modules.update(stashed_modules)


def _default_searle_config_path() -> str:
    # src/models/searle.py → src/configs/models/searle.yaml
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "configs",
        "models",
        "searle.yaml",
    )


def load_searle_config(path: Optional[str] = None) -> dict:
    path = path or _default_searle_config_path()
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return data["searle"]


def load_searle_model(config: dict, device: str = "cuda") -> Tuple[Any, Callable]:
    """
    مدل SEARLE را از طریق torch.hub بارگذاری می‌کند.

    Returns:
        (phi, encode_with_pseudo_tokens) — same contract as miccunifi/SEARLE hubconf.
        Caller must pass the matching OpenAI CLIP model into encode_with_pseudo_tokens.
    """
    searle_dir = config["searle_dir"]
    backbone = config.get("backbone", "ViT-B/32")
    source = config.get("source", "local")

    if source == "local" and not os.path.isdir(searle_dir):
        raise FileNotFoundError(
            f"مسیر SEARLE پیدا نشد: {searle_dir}. "
            f"ابتدا ریپو را کلون کن: git clone https://github.com/miccunifi/SEARLE"
        )

    with _searle_import_context(searle_dir):
        loaded = torch.hub.load(
            repo_or_dir=searle_dir,
            source=source,
            model="searle",
            backbone=backbone,
        )

    # Official hub returns (phi, encode_with_pseudo_tokens).
    # Guard against accidental (phi, clip_model) unpacking mistakes.
    if not isinstance(loaded, (tuple, list)) or len(loaded) < 2:
        raise RuntimeError(
            f"Unexpected SEARLE hub return value: expected "
            f"(phi, encode_with_pseudo_tokens), got {type(loaded)}"
        )
    phi, encode_with_pseudo_tokens = loaded[0], loaded[1]
    if not callable(encode_with_pseudo_tokens):
        raise TypeError(
            "SEARLE hub second return value must be encode_with_pseudo_tokens "
            f"(callable), got {type(encode_with_pseudo_tokens)}. "
            "Do not treat it as a CLIP model."
        )

    phi = phi.to(device).eval()
    return phi, encode_with_pseudo_tokens


def load_searle_preprocess(config: dict, fallback_preprocess=None):
    """
    Prefer SEARLE targetpad preprocess (paper setup); fall back to CLIP preprocess.

    Result.txt: SEARLE strong on CIRCO but weak on CIRR — often a preprocess mismatch.
    """
    searle_dir = config.get("searle_dir")
    target_ratio = float(config.get("targetpad_ratio", 1.25))
    size = int(config.get("image_size", 224))

    if searle_dir and os.path.isdir(searle_dir):
        try:
            with _searle_import_context(searle_dir):
                from src.utils.data_utils import targetpad_transform  # type: ignore

                print(
                    f"✅ SEARLE targetpad preprocess (ratio={target_ratio}, size={size})"
                )
                return targetpad_transform(target_ratio, size)
        except Exception as e:
            print(f"⚠️ SEARLE targetpad unavailable ({e}); using CLIP preprocess.")

    if fallback_preprocess is None:
        raise RuntimeError("No SEARLE/CLIP preprocess available")
    return fallback_preprocess


@torch.no_grad()
def get_searle_image_feature(clip_model, images, device: str = "cuda"):
    """
    ویژگی تصویر را استخراج و L2-normalize می‌کند.
    نرمال‌سازی برای عملکرد صحیح SEARLE در فضای شباهت کسینوسی ضروری است.
    """
    images = images.to(device)
    image_features = clip_model.encode_image(images)
    image_features = torch.nn.functional.normalize(image_features, dim=-1)
    return image_features
