"""
DEPRECATED — do not use this file for evaluation.

This legacy monolith is broken (CLIP/OpenCLIP overwrite, incomplete statements,
outdated CIRR target parsing) and has been retired.

Use the modular entrypoint instead:

    python run_eval.py --dataset cirr --image_folder ... --json_path ...
    python run_eval.py --dataset circo --image_folder ... --json_path ...
"""

import sys
import warnings

_DEPRECATION_MSG = (
    "fullMain.py is deprecated and unsafe to run. "
    "Use: python run_eval.py --dataset <cirr|circo> --image_folder ... --json_path ..."
)

warnings.warn(_DEPRECATION_MSG, DeprecationWarning, stacklevel=2)

if __name__ == "__main__":
    print(f"ERROR: {_DEPRECATION_MSG}", file=sys.stderr)
    sys.exit(1)
